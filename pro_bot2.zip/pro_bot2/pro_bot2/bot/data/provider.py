from __future__ import annotations

import hashlib
import logging
from dataclasses import asdict
from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd
import requests

from bot.config import AppConfig
from bot.models import MarketBar
from bot.storage.repository import Repository

logger = logging.getLogger(__name__)


class MarketDataProvider:
    def __init__(self, config: AppConfig, repository: Repository):
        self.config = config
        self.repository = repository
        self.session = requests.Session()

    def fetch(self, symbol: str) -> tuple[list[MarketBar], str, bool]:
        if self.config.data_provider == 'twelvedata' and self.config.twelvedata_api_key:
            try:
                return self._fetch_twelvedata(symbol), 'twelvedata', False
            except Exception as exc:
                logger.exception('Twelve Data failed')
                self.repository.log_event('ERROR', 'data', f'Twelve Data failure for {symbol}', {'error': str(exc)})
                if self.config.allow_demo_fallback:
                    return self._demo(symbol), 'demo', True
                raise
        return self._demo(symbol), 'demo', False

    def _fetch_twelvedata(self, symbol: str) -> list[MarketBar]:
        url = 'https://api.twelvedata.com/time_series'
        params = {
            'symbol': symbol.replace('/', ''),
            'interval': self.config.timeframe,
            'outputsize': max(self.config.lookback_bars, 180),
            'apikey': self.config.twelvedata_api_key,
            'format': 'JSON',
        }
        r = self.session.get(url, params=params, timeout=self.config.api_timeout_seconds)
        r.raise_for_status()
        payload = r.json()
        if 'values' not in payload:
            raise RuntimeError(payload.get('message', 'Invalid provider response'))
        bars: list[MarketBar] = []
        for row in reversed(payload['values']):
            bars.append(MarketBar(symbol=symbol, timeframe=self.config.timeframe, timestamp=row['datetime'], open=float(row['open']), high=float(row['high']), low=float(row['low']), close=float(row['close']), volume=float(row.get('volume') or 0), source='twelvedata', meta={'provider': 'twelvedata'}))
        return bars

    def _demo(self, symbol: str) -> list[MarketBar]:
        seed = int(hashlib.sha256(f'{symbol}|{self.config.timeframe}|{self.config.demo_seed}'.encode()).hexdigest(), 16) % (2**32)
        rng = np.random.default_rng(seed)
        n = max(self.config.lookback_bars, 180)
        price = 100 + (seed % 5000) / 100
        series = []
        drift = rng.normal(0.03, 0.06)
        vol = 0.55 if 'XAU' in symbol else 0.35
        closes = []
        for _ in range(n):
            price = max(0.01, price * (1 + rng.normal(drift, vol) / 100))
            closes.append(price)
        opens = [closes[0]] + closes[:-1]
        highs = [max(o, c) * (1 + abs(rng.normal(0.08, 0.04)) / 100) for o, c in zip(opens, closes)]
        lows = [min(o, c) * (1 - abs(rng.normal(0.08, 0.04)) / 100) for o, c in zip(opens, closes)]
        vols = rng.integers(1000, 4000, size=n)
        now = datetime.now(timezone.utc)
        step = {'1m': timedelta(minutes=1), '5m': timedelta(minutes=5), '15m': timedelta(minutes=15), '30m': timedelta(minutes=30), '1h': timedelta(hours=1), '4h': timedelta(hours=4), '1d': timedelta(days=1)}.get(self.config.timeframe.lower(), timedelta(hours=1))
        for i in range(n):
            ts = now - step * (n - i - 1)
            series.append(MarketBar(symbol=symbol, timeframe=self.config.timeframe, timestamp=ts.isoformat(), open=float(round(opens[i], 5)), high=float(round(highs[i], 5)), low=float(round(lows[i], 5)), close=float(round(closes[i], 5)), volume=float(vols[i]), source='demo', meta={'provider': 'demo'}))
        self.repository.store_bars_cache(symbol, self.config.timeframe, series[-1].timestamp, [asdict(b) for b in series])
        return series

    @staticmethod
    def to_dataframe(bars: list[MarketBar]) -> pd.DataFrame:
        df = pd.DataFrame([asdict(b) for b in bars])
        if df.empty:
            return df
        df['timestamp'] = pd.to_datetime(df['timestamp'], utc=True, errors='coerce')
        for col in ['open', 'high', 'low', 'close', 'volume']:
            df[col] = pd.to_numeric(df[col], errors='coerce')
        return df.dropna(subset=['timestamp', 'open', 'high', 'low', 'close'])
