from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List


def iso(dt: datetime | None = None) -> str:
    return (dt or datetime.now(timezone.utc)).isoformat()


@dataclass(slots=True)
class MarketBar:
    symbol: str
    timeframe: str
    timestamp: str
    open: float
    high: float
    low: float
    close: float
    volume: float
    source: str = 'unknown'
    meta: Dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class SignalDecision:
    symbol: str
    timeframe: str
    direction: str
    score: int
    confidence: float
    status: str
    price: float
    candle_time: str
    created_at: str
    reasons: List[str] = field(default_factory=list)
    filters: List[str] = field(default_factory=list)
    indicators: Dict[str, float] = field(default_factory=dict)
    source: str = 'strategy'

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class TradeRecord:
    id: int | None
    symbol: str
    timeframe: str
    direction: str
    entry_price: float
    entry_time: str
    status: str
    score: int
    reasons: str
    exit_price: float | None = None
    exit_time: str | None = None
    pnl_pct: float | None = None
    outcome: str | None = None
    meta: str | None = None


@dataclass(slots=True)
class BotState:
    bot_name: str = 'ProBot'
    status: str = 'starting'
    current_symbol: str = ''
    last_signal: Dict[str, Any] = field(default_factory=dict)
    score: int = 0
    direction: str = 'HOLD'
    last_update: str = ''
    last_cycle_started: str = ''
    last_cycle_finished: str = ''
    active_trades: int = 0
    wins: int = 0
    losses: int = 0
    daily_pnl_pct: float = 0.0
    weekly_pnl_pct: float = 0.0
    monthly_pnl_pct: float = 0.0
    recent_errors: List[Dict[str, Any]] = field(default_factory=list)
    alerts: List[str] = field(default_factory=list)
    active_filters: List[str] = field(default_factory=list)
    uptime_seconds: float = 0.0
    api_fallback_active: bool = False
    last_provider: str = 'demo'
    last_heartbeat: str = ''
    error_count_24h: int = 0
    metrics: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BotState':
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
