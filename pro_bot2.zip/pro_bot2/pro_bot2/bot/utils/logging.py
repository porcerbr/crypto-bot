from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path


def setup_logging(log_dir: Path, level: str = 'INFO') -> None:
    if logging.getLogger().handlers:
        return
    log_dir.mkdir(parents=True, exist_ok=True)
    root = logging.getLogger()
    root.setLevel(level.upper())
    fmt = logging.Formatter('%(asctime)s | %(levelname)s | %(name)s | %(message)s')

    stream = logging.StreamHandler()
    stream.setFormatter(fmt)
    root.addHandler(stream)

    file_handler = RotatingFileHandler(log_dir / 'bot.log', maxBytes=2_000_000, backupCount=5, encoding='utf-8')
    file_handler.setFormatter(fmt)
    root.addHandler(file_handler)
