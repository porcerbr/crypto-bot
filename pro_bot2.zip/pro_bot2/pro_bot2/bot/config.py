from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

from dotenv import load_dotenv

load_dotenv()


def _bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {'1', 'true', 'yes', 'y', 'on'}


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except Exception:
        return default


def _float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, str(default)))
    except Exception:
        return default


def _csv(name: str, default: str) -> List[str]:
    raw = os.getenv(name, default)
    return [item.strip() for item in raw.split(',') if item.strip()]


@dataclass(slots=True)
class AppConfig:
    app_name: str = os.getenv('APP_NAME', 'ProBot')
    env: str = os.getenv('ENV', 'production')
    debug: bool = _bool('DEBUG', False)
    secret_key: str = os.getenv('SECRET_KEY', 'change-me-now')
    bot_data_dir: Path = field(default_factory=lambda: Path(os.getenv('BOT_DATA_DIR', './instance')))
    log_dir: Path = field(default_factory=lambda: Path(os.getenv('LOG_DIR', './logs')))
    log_level: str = os.getenv('LOG_LEVEL', 'INFO').upper()
    symbols: List[str] = field(default_factory=lambda: _csv('SYMBOLS', 'EUR/USD,XAU/USD,GBP/USD'))
    timeframe: str = os.getenv('TIMEFRAME', '1h')
    data_provider: str = os.getenv('DATA_PROVIDER', 'demo').lower()
    twelvedata_api_key: str = os.getenv('TWELVEDATA_API_KEY', '')
    api_timeout_seconds: int = _int('API_TIMEOUT_SECONDS', 15)
    update_interval_seconds: int = _int('UPDATE_INTERVAL_SECONDS', 300)
    history_limit: int = _int('HISTORY_LIMIT', 500)
    lookback_bars: int = _int('LOOKBACK_BARS', 180)
    min_bars: int = _int('MIN_BARS', 60)
    min_score: int = _int('MIN_SCORE', 65)
    max_open_trades: int = _int('MAX_OPEN_TRADES', 1)
    max_volatility_pct: float = _float('MAX_VOLATILITY_PCT', 4.5)
    allow_demo_fallback: bool = _bool('ALLOW_DEMO_FALLBACK', True)
    allow_execution_webhook: bool = _bool('ALLOW_EXECUTION_WEBHOOK', False)
    execution_webhook_url: str = os.getenv('EXECUTION_WEBHOOK_URL', '')
    block_on_high_impact: bool = _bool('BLOCK_ON_HIGH_IMPACT', True)
    high_impact_windows: List[str] = field(default_factory=lambda: _csv('HIGH_IMPACT_WINDOWS', ''))
    lookahead_bars: int = _int('LOOKAHEAD_BARS', 12)
    demo_seed: int = _int('DEMO_SEED', 42)
    port: int = _int('PORT', 8000)

    @property
    def db_path(self) -> Path:
        return self.bot_data_dir / 'bot.sqlite3'

    @property
    def state_path(self) -> Path:
        return self.bot_data_dir / 'state.json'

    @classmethod
    def from_env(cls) -> 'AppConfig':
        cfg = cls()
        cfg.bot_data_dir.mkdir(parents=True, exist_ok=True)
        cfg.log_dir.mkdir(parents=True, exist_ok=True)
        return cfg
