from __future__ import annotations

from datetime import datetime
from pathlib import Path

from flask import Flask, jsonify, render_template, request

from bot.config import AppConfig
from bot.core.runtime import BotRuntime

runtime: BotRuntime | None = None


def create_app(config: AppConfig) -> Flask:
    global runtime
    root = Path(__file__).resolve().parents[2]
    app = Flask(__name__, template_folder=str(root / 'templates'), static_folder=str(root / 'static'))
    app.config['SECRET_KEY'] = config.secret_key
    app.config['BOT_CONFIG'] = config
    if runtime is None:
        runtime = BotRuntime(config)
        runtime.start()

    @app.route('/')
    def index():
        state = runtime.monitoring.build_snapshot(runtime.state)
        metrics = runtime.repository.metrics_summary()
        trades = runtime.repository.recent_trades(limit=12)
        events = runtime.repository.recent_events(limit=12)
        equity = runtime.repository.equity_series(limit=60)
        return render_template('dashboard.html', state=state, metrics=metrics, trades=trades, events=events, equity=equity, config=config)

    @app.route('/api/status')
    def api_status():
        return jsonify(runtime.monitoring.build_snapshot(runtime.state).to_dict())

    @app.route('/api/trades')
    def api_trades():
        limit = min(int(request.args.get('limit', 50)), 200)
        return jsonify(runtime.repository.recent_trades(limit=limit))

    @app.route('/api/events')
    def api_events():
        limit = min(int(request.args.get('limit', 50)), 200)
        return jsonify(runtime.repository.recent_events(limit=limit))

    @app.route('/health')
    def health():
        return jsonify({'ok': True, 'status': runtime.state.status, 'timestamp': datetime.utcnow().isoformat()})

    return app
