from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timezone

from bot.config import AppConfig
from bot.data.provider import MarketDataProvider
from bot.execution.service import ExecutionService
from bot.models import BotState, iso
from bot.monitoring.service import MonitoringService
from bot.risk.manager import RiskManager
from bot.storage.repository import Repository
from bot.strategy.engine import StrategyEngine
from bot.utils.logging import setup_logging

logger = logging.getLogger(__name__)


class BotRuntime:
    def __init__(self, config: AppConfig):
        self.config = config
        setup_logging(config.log_dir, config.log_level)
        self.repository = Repository(config.db_path, config.state_path)
        self.state = self.repository.load_state()
        self.state.bot_name = config.app_name
        self.state.status = 'starting'
        self.provider = MarketDataProvider(config, self.repository)
        self.strategy = StrategyEngine(config)
        self.risk = RiskManager(config)
        self.execution = ExecutionService(config, self.repository)
        self.monitoring = MonitoringService(config, self.repository)
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self.run_forever, name='bot-loop', daemon=True)
        self._thread.start()
        logger.info('Bot runtime started')

    def stop(self) -> None:
        self._stop_event.set()

    def run_forever(self) -> None:
        while not self._stop_event.is_set():
            start = time.time()
            self._cycle()
            wait_for = max(2, self.config.update_interval_seconds - (time.time() - start))
            self._stop_event.wait(wait_for)

    def _cycle(self) -> None:
        with self._lock:
            self.state.status = 'running'
            self.state.last_cycle_started = iso()
            self.state.last_heartbeat = iso()
            self.state.last_update = iso()

        try:
            open_trades = self.repository.open_trades()
            self.state.active_trades = len(open_trades)
            for symbol in self.config.symbols:
                bars, provider_name, fallback = self.provider.fetch(symbol)
                df = self.provider.to_dataframe(bars)
                data_complete = len(df) >= self.config.min_bars
                decision = self.strategy.analyze(df.tail(self.config.lookback_bars), symbol, provider_name)
                risk = self.risk.evaluate(decision, open_trades=len(open_trades), data_complete=data_complete)
                self.state.current_symbol = symbol
                self.state.last_provider = provider_name
                self.state.api_fallback_active = fallback
                self.state.score = decision.score
                self.state.direction = decision.direction
                self.state.active_filters = risk.active_filters or decision.filters
                if decision.direction != 'HOLD':
                    self.state.last_signal = decision.to_dict()
                if decision.direction != 'HOLD' and risk.allowed and not self._duplicate(symbol, decision.candle_time, decision.direction):
                    self.execution.dispatch(decision, meta={'provider': provider_name, 'fallback': fallback, 'risk': risk.__dict__})
                    self.state.active_trades = len(self.repository.open_trades())
                self._resolve_trades(symbol, df)
            snapshot = self.monitoring.build_snapshot(self.state)
            snapshot.last_cycle_finished = iso()
            self.state = snapshot
            self.repository.save_state(self.state)
        except Exception as exc:
            logger.exception('Cycle failed')
            self.repository.log_event('ERROR', 'runtime', 'Falha no ciclo principal', {'error': str(exc)})
            self.state.status = 'degraded'
            self.state.recent_errors = self.repository.recent_errors(limit=10)
            self.state.alerts = ['O bot entrou em modo degradado.']
            self.repository.save_state(self.state)

    def _duplicate(self, symbol: str, candle_time: str, direction: str) -> bool:
        last = self.state.last_signal or {}
        return last.get('symbol') == symbol and last.get('candle_time') == candle_time and last.get('direction') == direction

    def _resolve_trades(self, symbol: str, df) -> None:
        open_trades = self.repository.open_trades()
        if df.empty or len(df) <= self.config.lookahead_bars or not open_trades:
            return
        latest_price = float(df['close'].iloc[-1])
        latest_time = str(df['timestamp'].iloc[-1])
        for trade in open_trades:
            if trade['symbol'] != symbol:
                continue
            entry_time = str(trade['entry_time'])
            try:
                idx = df.index[df['timestamp'].astype(str) == entry_time]
                if len(idx) == 0:
                    continue
                if int(idx[0]) > len(df) - self.config.lookahead_bars - 1:
                    continue
                entry = float(trade['entry_price'])
                if trade['direction'] == 'BUY':
                    pnl = ((latest_price - entry) / entry) * 100.0
                    outcome = 'win' if latest_price > entry else 'loss'
                else:
                    pnl = ((entry - latest_price) / entry) * 100.0
                    outcome = 'win' if latest_price < entry else 'loss'
                self.repository.close_trade(int(trade['id']), latest_price, latest_time, round(pnl, 2), outcome)
                self.repository.log_event('INFO', 'execution', f'Trade fechado: #{trade["id"]} {outcome}', {'trade_id': trade['id'], 'pnl_pct': round(pnl, 2)})
            except Exception as exc:
                self.repository.log_event('ERROR', 'execution', 'Falha ao fechar trade', {'trade_id': trade.get('id'), 'error': str(exc)})
