from __future__ import annotations

from dataclasses import asdict
from typing import Any, Dict

import requests

from bot.config import AppConfig
from bot.models import SignalDecision, TradeRecord
from bot.storage.repository import Repository


class ExecutionService:
    def __init__(self, config: AppConfig, repository: Repository):
        self.config = config
        self.repository = repository
        self.session = requests.Session()

    def dispatch(self, decision: SignalDecision, meta: Dict[str, Any] | None = None) -> TradeRecord:
        trade = TradeRecord(id=None, symbol=decision.symbol, timeframe=decision.timeframe, direction=decision.direction, entry_price=decision.price, entry_time=decision.candle_time, status='open', score=decision.score, reasons='; '.join(decision.reasons), meta=repr(meta or {}))
        trade.id = self.repository.insert_trade(trade)
        self.repository.log_event('INFO', 'execution', f'Signal registrado: {decision.symbol} {decision.direction} #{trade.id}', {'trade': asdict(trade), 'decision': decision.to_dict()})
        if self.config.allow_execution_webhook and self.config.execution_webhook_url:
            self._notify_webhook(decision, trade)
        return trade

    def _notify_webhook(self, decision: SignalDecision, trade: TradeRecord) -> None:
        payload = {'trade_id': trade.id, 'symbol': decision.symbol, 'timeframe': decision.timeframe, 'direction': decision.direction, 'score': decision.score, 'price': decision.price, 'candle_time': decision.candle_time, 'reasons': decision.reasons, 'indicators': decision.indicators}
        try:
            r = self.session.post(self.config.execution_webhook_url, json=payload, timeout=self.config.api_timeout_seconds)
            r.raise_for_status()
        except Exception as exc:
            self.repository.log_event('ERROR', 'execution', 'Falha ao enviar webhook', {'error': str(exc)})
