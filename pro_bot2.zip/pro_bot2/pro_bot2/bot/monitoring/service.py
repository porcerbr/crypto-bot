from __future__ import annotations

from datetime import datetime, timezone
from typing import List

from bot.config import AppConfig
from bot.models import BotState
from bot.storage.repository import Repository


class MonitoringService:
    def __init__(self, config: AppConfig, repository: Repository):
        self.config = config
        self.repository = repository
        self.started_at = datetime.now(timezone.utc)

    def build_snapshot(self, state: BotState) -> BotState:
        state.uptime_seconds = (datetime.now(timezone.utc) - self.started_at).total_seconds()
        metrics = self.repository.metrics_summary()
        state.error_count_24h = len(self.repository.recent_errors(limit=100))
        state.metrics = metrics
        state.wins = metrics.get('wins', 0)
        state.losses = metrics.get('losses', 0)
        state.daily_pnl_pct = self.repository.period_pnl(1)
        state.weekly_pnl_pct = self.repository.period_pnl(7)
        state.monthly_pnl_pct = self.repository.period_pnl(30)
        state.recent_errors = self.repository.recent_errors(limit=10)
        state.alerts = self._alerts(state)
        return state

    def _alerts(self, state: BotState) -> List[str]:
        alerts: List[str] = []
        if state.api_fallback_active:
            alerts.append('Fallback de dados ativo.')
        if state.error_count_24h >= 5:
            alerts.append('Volume alto de erros nas últimas 24h.')
        if state.active_trades >= self.config.max_open_trades:
            alerts.append('Limite de trades abertas atingido.')
        if not state.last_signal:
            alerts.append('Aguardando primeiro sinal válido.')
        return alerts
