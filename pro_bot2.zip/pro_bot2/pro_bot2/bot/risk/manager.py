from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import List

from bot.config import AppConfig
from bot.models import SignalDecision


@dataclass(slots=True)
class RiskDecision:
    allowed: bool
    reasons: List[str]
    active_filters: List[str]


class RiskManager:
    def __init__(self, config: AppConfig):
        self.config = config

    def evaluate(self, decision: SignalDecision, open_trades: int, data_complete: bool) -> RiskDecision:
        reasons: List[str] = []
        filters: List[str] = []
        allowed = True

        if not data_complete:
            allowed = False
            reasons.append('Dados incompletos.')
            filters.append('DATA_INCOMPLETE')
        if decision.direction == 'HOLD' or decision.score < self.config.min_score:
            allowed = False
            reasons.append('Sem confirmação mínima.')
            filters.append('MIN_SCORE')
        if open_trades >= self.config.max_open_trades:
            allowed = False
            reasons.append('Limite de trades abertos atingido.')
            filters.append('MAX_OPEN_TRADES')
        if decision.indicators.get('volatility_pct', 0.0) > self.config.max_volatility_pct:
            allowed = False
            reasons.append('Volatilidade excessiva.')
            filters.append('VOLATILITY')
        if self._high_impact_block():
            allowed = False
            reasons.append('Janela de alto impacto ativa.')
            filters.append('HIGH_IMPACT')

        return RiskDecision(allowed=allowed, reasons=reasons, active_filters=filters)

    def _high_impact_block(self) -> bool:
        if not self.config.block_on_high_impact or not self.config.high_impact_windows:
            return False
        now = datetime.now(timezone.utc)
        stamp = now.strftime('%Y-%m-%dT%H').lower()
        dow = now.strftime('%a').lower()
        for token in self.config.high_impact_windows:
            t = token.strip().lower()
            if t and (t in stamp or t == dow):
                return True
        return False
