from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from threading import Lock
from typing import Any, Dict, List, Optional

from bot.models import BotState, TradeRecord


class Repository:
    def __init__(self, db_path: Path, state_path: Path):
        self.db_path = db_path
        self.state_path = state_path
        self._lock = Lock()
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=30)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as conn:
            conn.execute('PRAGMA journal_mode=WAL;')
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS trades (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol TEXT NOT NULL,
                    timeframe TEXT NOT NULL,
                    direction TEXT NOT NULL,
                    entry_price REAL NOT NULL,
                    entry_time TEXT NOT NULL,
                    status TEXT NOT NULL,
                    score INTEGER NOT NULL,
                    reasons TEXT NOT NULL,
                    exit_price REAL,
                    exit_time TEXT,
                    pnl_pct REAL,
                    outcome TEXT,
                    meta TEXT
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts TEXT NOT NULL,
                    level TEXT NOT NULL,
                    category TEXT NOT NULL,
                    message TEXT NOT NULL,
                    payload TEXT
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS bars_cache (
                    symbol TEXT NOT NULL,
                    timeframe TEXT NOT NULL,
                    last_ts TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    PRIMARY KEY(symbol, timeframe)
                )
                """
            )
            conn.commit()

    @contextmanager
    def connection(self):
        with self._lock:
            conn = self._connect()
            try:
                yield conn
                conn.commit()
            finally:
                conn.close()

    def save_state(self, state: BotState) -> None:
        with self.state_path.open('w', encoding='utf-8') as fh:
            json.dump(state.to_dict(), fh, ensure_ascii=False, indent=2)

    def load_state(self) -> BotState:
        if self.state_path.exists():
            try:
                with self.state_path.open('r', encoding='utf-8') as fh:
                    return BotState.from_dict(json.load(fh))
            except Exception:
                pass
        return BotState()

    def log_event(self, level: str, category: str, message: str, payload: Optional[Dict[str, Any]] = None) -> None:
        with self.connection() as conn:
            conn.execute(
                'INSERT INTO events (ts, level, category, message, payload) VALUES (?, ?, ?, ?, ?)',
                (datetime.utcnow().isoformat(), level.upper(), category, message, json.dumps(payload or {}, ensure_ascii=False)),
            )

    def store_bars_cache(self, symbol: str, timeframe: str, last_ts: str, bars: List[Dict[str, Any]]) -> None:
        with self.connection() as conn:
            conn.execute(
                'INSERT INTO bars_cache(symbol, timeframe, last_ts, payload) VALUES (?, ?, ?, ?) ON CONFLICT(symbol, timeframe) DO UPDATE SET last_ts=excluded.last_ts, payload=excluded.payload',
                (symbol, timeframe, last_ts, json.dumps(bars, ensure_ascii=False)),
            )

    def recent_trades(self, limit: int = 25) -> List[Dict[str, Any]]:
        with self.connection() as conn:
            rows = conn.execute('SELECT * FROM trades ORDER BY id DESC LIMIT ?', (limit,)).fetchall()
            return [dict(r) for r in rows]

    def open_trades(self) -> List[Dict[str, Any]]:
        with self.connection() as conn:
            rows = conn.execute("SELECT * FROM trades WHERE status='open' ORDER BY id ASC").fetchall()
            return [dict(r) for r in rows]

    def recent_events(self, limit: int = 25) -> List[Dict[str, Any]]:
        with self.connection() as conn:
            rows = conn.execute('SELECT * FROM events ORDER BY id DESC LIMIT ?', (limit,)).fetchall()
            return [dict(r) for r in rows]

    def recent_errors(self, limit: int = 25) -> List[Dict[str, Any]]:
        with self.connection() as conn:
            rows = conn.execute("SELECT * FROM events WHERE level IN ('ERROR','CRITICAL') ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
            return [dict(r) for r in rows]

    def metrics_summary(self) -> Dict[str, Any]:
        with self.connection() as conn:
            total = conn.execute('SELECT COUNT(*) AS c FROM trades').fetchone()['c']
            open_count = conn.execute("SELECT COUNT(*) AS c FROM trades WHERE status='open'").fetchone()['c']
            wins = conn.execute("SELECT COUNT(*) AS c FROM trades WHERE outcome='win'").fetchone()['c']
            losses = conn.execute("SELECT COUNT(*) AS c FROM trades WHERE outcome='loss'").fetchone()['c']
            pnl = conn.execute("SELECT COALESCE(SUM(pnl_pct),0) AS p FROM trades WHERE status='closed'").fetchone()['p']
            return {'total_trades': total, 'open_trades': open_count, 'wins': wins, 'losses': losses, 'closed_pnl_pct': round(float(pnl or 0), 2)}

    def equity_series(self, limit: int = 60) -> List[Dict[str, Any]]:
        with self.connection() as conn:
            rows = conn.execute("SELECT exit_time, pnl_pct FROM trades WHERE status='closed' AND pnl_pct IS NOT NULL ORDER BY id ASC LIMIT ?", (limit,)).fetchall()
            equity = 100.0
            series = []
            for row in rows:
                equity *= 1 + float(row['pnl_pct']) / 100.0
                series.append({'time': row['exit_time'], 'equity': round(equity, 2)})
            return series


    def period_pnl(self, days: int) -> float:
        with self.connection() as conn:
            rows = conn.execute(
                "SELECT exit_time, pnl_pct FROM trades WHERE status='closed' AND pnl_pct IS NOT NULL"
            ).fetchall()
            cutoff = datetime.utcnow().timestamp() - days * 86400
            total = 0.0
            for row in rows:
                try:
                    ts = datetime.fromisoformat(row['exit_time'].replace('Z', '+00:00')).timestamp()
                except Exception:
                    continue
                if ts >= cutoff:
                    total += float(row['pnl_pct'])
            return round(total, 2)

    def outcomes_summary(self) -> Dict[str, int]:
        with self.connection() as conn:
            wins = conn.execute("SELECT COUNT(*) AS c FROM trades WHERE outcome='win'").fetchone()['c']
            losses = conn.execute("SELECT COUNT(*) AS c FROM trades WHERE outcome='loss'").fetchone()['c']
            return {'wins': wins, 'losses': losses}

    def insert_trade(self, trade: TradeRecord) -> int:
        with self.connection() as conn:
            cursor = conn.execute(
                """
                INSERT INTO trades (
                    symbol, timeframe, direction, entry_price, entry_time, status, score, reasons,
                    exit_price, exit_time, pnl_pct, outcome, meta
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (trade.symbol, trade.timeframe, trade.direction, trade.entry_price, trade.entry_time, trade.status, trade.score, trade.reasons, trade.exit_price, trade.exit_time, trade.pnl_pct, trade.outcome, trade.meta),
            )
            return int(cursor.lastrowid)

    def close_trade(self, trade_id: int, exit_price: float, exit_time: str, pnl_pct: float, outcome: str) -> None:
        with self.connection() as conn:
            conn.execute('UPDATE trades SET status=?, exit_price=?, exit_time=?, pnl_pct=?, outcome=? WHERE id=?', ('closed', exit_price, exit_time, pnl_pct, outcome, trade_id))
