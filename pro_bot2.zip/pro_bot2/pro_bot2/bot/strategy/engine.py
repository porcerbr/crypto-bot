from __future__ import annotations

import numpy as np
import pandas as pd

from bot.config import AppConfig
from bot.models import SignalDecision, iso


class StrategyEngine:
    def __init__(self, config: AppConfig):
        self.config = config

    def analyze(self, df: pd.DataFrame, symbol: str, provider: str) -> SignalDecision:
        if df.empty or len(df) < self.config.min_bars:
            price = float(df['close'].iloc[-1]) if not df.empty else 0.0
            return SignalDecision(symbol=symbol, timeframe=self.config.timeframe, direction='HOLD', score=0, confidence=0.0, status='insufficient_data', price=price, candle_time=iso(), created_at=iso(), reasons=['Dados insuficientes.'], filters=['MIN_BARS'], indicators={}, source=provider)

        data = df.copy().sort_values('timestamp').reset_index(drop=True)
        data['sma_fast'] = data['close'].rolling(9).mean()
        data['sma_slow'] = data['close'].rolling(21).mean()
        data['ema20'] = data['close'].ewm(span=20, adjust=False).mean()
        data['ema50'] = data['close'].ewm(span=50, adjust=False).mean()
        data['rsi'] = self._rsi(data['close'], 14)
        data['atr'] = self._atr(data, 14)
        data['ret1'] = data['close'].pct_change()
        data['volatility_pct'] = data['ret1'].rolling(20).std() * 100 * np.sqrt(20)
        data['volume_avg'] = data['volume'].rolling(20).mean()
        last = data.iloc[-1]
        close = float(last['close'])

        score = 0
        reasons: list[str] = []
        filters: list[str] = []

        trend_up = last['sma_fast'] > last['sma_slow'] > last['ema50']
        trend_down = last['sma_fast'] < last['sma_slow'] < last['ema50']
        momentum_up = close > float(last['ema20']) and float(last['rsi']) >= 52
        momentum_down = close < float(last['ema20']) and float(last['rsi']) <= 48
        candle_bull = last['close'] > last['open']
        candle_bear = last['close'] < last['open']
        vol_ok = np.isfinite(last['volatility_pct']) and float(last['volatility_pct']) <= self.config.max_volatility_pct
        volume_ok = np.isfinite(last['volume_avg']) and float(last['volume']) >= 0.8 * float(last['volume_avg']) if np.isfinite(last['volume_avg']) else True

        if trend_up or trend_down:
            score += 25
            reasons.append('Tendência alinhada.')
        if momentum_up or momentum_down:
            score += 20
            reasons.append('Momentum confirmado.')
        if candle_bull or candle_bear:
            score += 10
            reasons.append('Candle de confirmação.')
        if vol_ok:
            score += 10
            reasons.append('Volatilidade segura.')
        else:
            filters.append('VOLATILITY')
            reasons.append('Volatilidade fora do limite.')
        if volume_ok:
            score += 10
            reasons.append('Volume saudável.')
        if float(last['atr']) > 0:
            score += 5
            reasons.append('ATR disponível.')

        direction = 'HOLD'
        status = 'hold'
        if trend_up and momentum_up and candle_bull and vol_ok:
            direction = 'BUY'
            status = 'candidate'
            score += 10
        elif trend_down and momentum_down and candle_bear and vol_ok:
            direction = 'SELL'
            status = 'candidate'
            score += 10

        score = int(max(0, min(100, score)))
        if score < self.config.min_score:
            if direction != 'HOLD':
                reasons.append(f'Score abaixo do mínimo ({self.config.min_score}).')
            direction = 'HOLD'
            status = 'hold'

        indicators = {
            'close': round(close, 5),
            'sma_fast': round(float(last['sma_fast']), 5) if np.isfinite(last['sma_fast']) else 0.0,
            'sma_slow': round(float(last['sma_slow']), 5) if np.isfinite(last['sma_slow']) else 0.0,
            'ema20': round(float(last['ema20']), 5) if np.isfinite(last['ema20']) else 0.0,
            'ema50': round(float(last['ema50']), 5) if np.isfinite(last['ema50']) else 0.0,
            'rsi': round(float(last['rsi']), 2) if np.isfinite(last['rsi']) else 0.0,
            'atr': round(float(last['atr']), 5) if np.isfinite(last['atr']) else 0.0,
            'volatility_pct': round(float(last['volatility_pct']), 2) if np.isfinite(last['volatility_pct']) else 0.0,
        }

        return SignalDecision(symbol=symbol, timeframe=self.config.timeframe, direction=direction, score=score, confidence=round(score / 100.0, 2), status=status, price=close, candle_time=pd.Timestamp(last['timestamp']).isoformat(), created_at=iso(), reasons=reasons, filters=filters, indicators=indicators, source=provider)

    @staticmethod
    def _rsi(series: pd.Series, period: int = 14) -> pd.Series:
        delta = series.diff()
        gain = delta.clip(lower=0)
        loss = -delta.clip(upper=0)
        avg_gain = gain.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
        avg_loss = loss.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
        rs = avg_gain / avg_loss.replace(0, np.nan)
        return (100 - (100 / (1 + rs))).fillna(50)

    @staticmethod
    def _atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
        tr = pd.concat([
            (df['high'] - df['low']),
            (df['high'] - df['close'].shift()).abs(),
            (df['low'] - df['close'].shift()).abs(),
        ], axis=1).max(axis=1)
        return tr.ewm(alpha=1 / period, min_periods=period, adjust=False).mean().fillna(0)
