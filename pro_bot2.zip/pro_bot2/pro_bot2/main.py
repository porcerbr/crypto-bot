from bot.core.app import create_app
from bot.config import AppConfig
config = AppConfig.from_env()
app = create_app(config)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=config.port, debug=config.debug, threaded=True)
