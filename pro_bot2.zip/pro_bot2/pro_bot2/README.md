# ProBot

Base profissional para bot de sinais com arquitetura modular, dashboard web, persistência local, logs e fallback de dados.

## Módulos
- `core`: orquestra o ciclo do bot e o servidor web.
- `data`: coleta e normalização dos candles.
- `strategy`: cálculo dos indicadores e geração de sinal.
- `risk`: filtros de segurança.
- `execution`: registro/encaminhamento do sinal.
- `storage`: banco SQLite e estado em JSON.
- `monitoring`: snapshot de saúde e alertas.
- `dashboard`: interface web responsiva.

## Rodar localmente
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
python main.py
```

Abra `http://localhost:8000`.

## Variáveis principais
- `DATA_PROVIDER=demo` para rodar sem API externa.
- `DATA_PROVIDER=twelvedata` + `TWELVEDATA_API_KEY` para usar API real.
- `BOT_DATA_DIR=./instance` para salvar estado e banco.
- `SYMBOLS=EUR/USD,XAU/USD,GBP/USD` para definir ativos.
- `UPDATE_INTERVAL_SECONDS=300` para ajustar o ciclo.

## Deploy no Railway
1. Envie este projeto para um repositório no GitHub.
2. No Railway, crie um projeto e conecte o repositório.
3. Configure as variáveis em **Variables**.
4. Use o comando do `Procfile` ou este equivalente:
   `gunicorn --workers 1 --threads 4 --timeout 120 --bind 0.0.0.0:$PORT main:app`
5. Abra a URL pública do serviço.

## Observação de arquitetura
A base já salva estado, logs e histórico no diretório configurado por `BOT_DATA_DIR`. Para produção com retenção maior, a mesma camada de storage pode ser trocada por Postgres sem quebrar o restante do sistema.
